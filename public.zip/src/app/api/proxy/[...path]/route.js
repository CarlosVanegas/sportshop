import { NextResponse } from "next/server"

export async function GET(request, { params }) {
  const path = params.path || []
  const apiPath = path.join("/")
  const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api"

  const url = `${API_BASE_URL}/${apiPath}`

  console.log(`Proxy: Redirigiendo solicitud GET a ${url}`)

  try {
    const response = await fetch(url, {
      headers: {
        "Content-Type": "application/json",
      },
      cache: "no-store",
    })

    if (!response.ok) {
      console.error(`Error en proxy: ${response.status} ${response.statusText}`)
      return NextResponse.json(
          { error: `Error al conectar con la API: ${response.status} ${response.statusText}` },
          { status: response.status },
      )
    }

    const data = await response.json()
    console.log(`Proxy: Respuesta recibida con ${data.length} elementos`)
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error en proxy:", error)
    return NextResponse.json({ error: `Error al conectar con la API: ${error.message}` }, { status: 500 })
  }
}

export async function POST(request, { params }) {
  const path = params.path || []
  const apiPath = path.join("/")
  const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api"

  const url = `${API_BASE_URL}/${apiPath}`

  try {
    const body = await request.json()

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    })

    if (!response.ok) {
      return NextResponse.json(
          { error: `Error al conectar con la API: ${response.status} ${response.statusText}` },
          { status: response.status },
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error en proxy:", error)
    return NextResponse.json({ error: `Error al conectar con la API: ${error.message}` }, { status: 500 })
  }
}

export async function PUT(request, { params }) {
  const path = params.path || []
  const apiPath = path.join("/")
  const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api"

  const url = `${API_BASE_URL}/${apiPath}`

  try {
    const body = await request.json()

    const response = await fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    })

    if (!response.ok) {
      return NextResponse.json(
          { error: `Error al conectar con la API: ${response.status} ${response.statusText}` },
          { status: response.status },
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error en proxy:", error)
    return NextResponse.json({ error: `Error al conectar con la API: ${error.message}` }, { status: 500 })
  }
}

export async function DELETE(request, { params }) {
  const path = params.path || []
  const apiPath = path.join("/")
  const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api"

  const url = `${API_BASE_URL}/${apiPath}`

  try {
    const response = await fetch(url, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (response.status === 204) {
      return new NextResponse(null, { status: 204 })
    }

    if (!response.ok) {
      return NextResponse.json(
          { error: `Error al conectar con la API: ${response.status} ${response.statusText}` },
          { status: response.status },
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error en proxy:", error)
    return NextResponse.json({ error: `Error al conectar con la API: ${error.message}` }, { status: 500 })
  }
}
