"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Trash2, Plus, Minus, ShoppingBag } from "lucide-react"
import { useCart } from "@/context/CartContext"
import { useAuth } from "@/context/AuthContext"
import { confirmOrder } from "@/services/orderService"
import { useRouter } from "next/navigation"

export default function CartPage() {
    const { cartItems, loading, removeFromCart, updateQuantity, cartTotal, refreshCart } = useCart()
    const { isAuthenticated } = useAuth()
    const [isProcessing, setIsProcessing] = useState(false)
    const [orderError, setOrderError] = useState("")
    const router = useRouter()

    const handleRemoveItem = async (itemId) => {
        try {
            await removeFromCart(itemId)
        } catch (error) {
            console.error("Error al eliminar item:", error)
        }
    }

    const handleQuantityChange = async (itemId, newQuantity) => {
        if (newQuantity < 1) return

        try {
            await updateQuantity(itemId, newQuantity)
        } catch (error) {
            console.error("Error al actualizar cantidad:", error)
        }
    }

    const handleCheckout = async () => {
        if (!isAuthenticated) {
            router.push("/login?redirect=cart")
            return
        }

        setIsProcessing(true)
        setOrderError("")

        try {
            const response = await confirmOrder()
            // Refrescar el carrito después de confirmar el pedido
            await refreshCart()
            // Redirigir a la página de confirmación
            router.push(`/pedidos/${response.orderId}?success=true`)
        } catch (error) {
            console.error("Error al procesar el pedido:", error)
            setOrderError(error.message || "Error al procesar el pedido. Inténtalo de nuevo.")
        } finally {
            setIsProcessing(false)
        }
    }

    if (loading) {
        return (
            <div className="container mx-auto py-12 px-4">
                <h1 className="text-2xl font-bold mb-8">Tu Carrito</h1>
                <div className="flex justify-center">
                    <div className="animate-pulse text-center">
                        <p className="text-neutral-500">Cargando carrito...</p>
                    </div>
                </div>
            </div>
        )
    }

    if (!cartItems || cartItems.length === 0) {
        return (
            <div className="container mx-auto py-12 px-4">
                <h1 className="text-2xl font-bold mb-8">Tu Carrito</h1>
                <div className="bg-white rounded-xl shadow-sm p-8 text-center">
                    <ShoppingBag className="h-16 w-16 mx-auto mb-4 text-neutral-300" />
                    <h2 className="text-xl font-medium mb-2">Tu carrito está vacío</h2>
                    <p className="text-neutral-500 mb-6">Parece que aún no has añadido productos a tu carrito</p>
                    <Link
                        href="/productos"
                        className="inline-block bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-6 rounded-lg transition-colors"
                    >
                        Explorar Productos
                    </Link>
                </div>
            </div>
        )
    }

    return (
        <div className="container mx-auto py-12 px-4">
            <h1 className="text-2xl font-bold mb-8">Tu Carrito</h1>

            {orderError && <div className="bg-red-50 text-red-700 p-4 rounded-lg mb-6">{orderError}</div>}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                        <div className="p-6 border-b border-neutral-100">
                            <h2 className="text-lg font-medium">Productos ({cartItems.length})</h2>
                        </div>

                        <div className="divide-y divide-neutral-100">
                            {cartItems.map((item) => (
                                <div key={item.id} className="p-6 flex flex-col sm:flex-row items-start sm:items-center">
                                    <div className="relative h-20 w-20 rounded-lg overflow-hidden bg-neutral-100 flex-shrink-0 mb-4 sm:mb-0">
                                        <Image
                                            src={item.product?.imageUrl || "/placeholder.svg"}
                                            alt={item.product?.description || "Producto"}
                                            fill
                                            className="object-cover"
                                        />
                                    </div>

                                    <div className="sm:ml-6 flex-grow">
                                        <h3 className="font-medium">{item.product?.description || "Producto"}</h3>
                                        <p className="text-neutral-500 text-sm">${item.product?.price.toFixed(2)}</p>
                                    </div>

                                    <div className="flex items-center mt-4 sm:mt-0">
                                        <button
                                            onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                                            className="p-1 rounded-full hover:bg-neutral-100"
                                            aria-label="Disminuir cantidad"
                                        >
                                            <Minus className="h-4 w-4 text-neutral-600" />
                                        </button>
                                        <span className="mx-2 w-8 text-center">{item.quantity}</span>
                                        <button
                                            onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                                            className="p-1 rounded-full hover:bg-neutral-100"
                                            aria-label="Aumentar cantidad"
                                        >
                                            <Plus className="h-4 w-4 text-neutral-600" />
                                        </button>
                                    </div>

                                    <div className="mt-4 sm:mt-0 sm:ml-6 flex items-center">
                                        <span className="font-medium mr-4">${(item.product?.price * item.quantity).toFixed(2)}</span>
                                        <button
                                            onClick={() => handleRemoveItem(item.id)}
                                            className="p-1 rounded-full hover:bg-neutral-100 text-red-500"
                                            aria-label="Eliminar"
                                        >
                                            <Trash2 className="h-5 w-5" />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="lg:col-span-1">
                    <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
                        <h2 className="text-lg font-medium mb-4">Resumen del Pedido</h2>

                        <div className="space-y-3 mb-6">
                            <div className="flex justify-between">
                                <span className="text-neutral-600">Subtotal</span>
                                <span>${cartTotal.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-neutral-600">Envío</span>
                                <span>Gratis</span>
                            </div>
                            <div className="border-t border-neutral-100 pt-3 flex justify-between font-medium">
                                <span>Total</span>
                                <span>${cartTotal.toFixed(2)}</span>
                            </div>
                        </div>

                        <button
                            onClick={handleCheckout}
                            disabled={isProcessing}
                            className="w-full bg-primary-600 hover:bg-primary-700 text-white font-medium py-3 px-4 rounded-lg transition-colors disabled:opacity-70"
                        >
                            {isProcessing ? "Procesando..." : "Finalizar Compra"}
                        </button>

                        <div className="mt-4">
                            <Link
                                href="/productos"
                                className="text-primary-600 hover:text-primary-700 text-sm flex items-center justify-center"
                            >
                                Seguir comprando
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
