"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useAuth } from "@/context/AuthContext"
import { getUserOrders } from "@/services/orderService"
import { ShoppingBag, ChevronRight, Calendar, Clock } from "lucide-react"

export default function OrdersPage() {
    const { isAuthenticated } = useAuth()
    const [orders, setOrders] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)

    useEffect(() => {
        const fetchOrders = async () => {
            if (!isAuthenticated) return

            setLoading(true)
            setError(null)
            try {
                const data = await getUserOrders()
                setOrders(data || [])
            } catch (err) {
                console.error("Error al cargar pedidos:", err)
                setError("No se pudieron cargar tus pedidos. Por favor, intenta de nuevo más tarde.")
            } finally {
                setLoading(false)
            }
        }

        fetchOrders()
    }, [isAuthenticated])

    if (!isAuthenticated) {
        return (
            <div className="container mx-auto py-12 px-4">
                <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden p-8 text-center">
                    <h1 className="text-2xl font-bold mb-4">Acceso Restringido</h1>
                    <p className="text-neutral-600 mb-6">Debes iniciar sesión para ver tus pedidos</p>
                    <Link
                        href="/login?redirect=pedidos"
                        className="inline-block bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-6 rounded-lg transition-colors"
                    >
                        Iniciar Sesión
                    </Link>
                </div>
            </div>
        )
    }

    if (loading) {
        return (
            <div className="container mx-auto py-12 px-4">
                <h1 className="text-2xl font-bold mb-8">Mis Pedidos</h1>
                <div className="flex justify-center">
                    <div className="animate-pulse text-center">
                        <p className="text-neutral-500">Cargando pedidos...</p>
                    </div>
                </div>
            </div>
        )
    }

    if (error) {
        return (
            <div className="container mx-auto py-12 px-4">
                <h1 className="text-2xl font-bold mb-8">Mis Pedidos</h1>
                <div className="bg-red-50 text-red-700 p-6 rounded-xl">
                    <p>{error}</p>
                </div>
            </div>
        )
    }

    if (orders.length === 0) {
        return (
            <div className="container mx-auto py-12 px-4">
                <h1 className="text-2xl font-bold mb-8">Mis Pedidos</h1>
                <div className="bg-white rounded-xl shadow-sm p-8 text-center">
                    <ShoppingBag className="h-16 w-16 mx-auto mb-4 text-neutral-300" />
                    <h2 className="text-xl font-medium mb-2">No tienes pedidos</h2>
                    <p className="text-neutral-500 mb-6">Aún no has realizado ningún pedido</p>
                    <Link
                        href="/productos"
                        className="inline-block bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-6 rounded-lg transition-colors"
                    >
                        Explorar Productos
                    </Link>
                </div>
            </div>
        )
    }

    // Función para formatear la fecha
    const formatDate = (dateString) => {
        const date = new Date(dateString)
        return date.toLocaleDateString("es-ES", {
            year: "numeric",
            month: "long",
            day: "numeric",
        })
    }

    // Función para formatear la hora
    const formatTime = (dateString) => {
        const date = new Date(dateString)
        return date.toLocaleTimeString("es-ES", {
            hour: "2-digit",
            minute: "2-digit",
        })
    }

    // Función para obtener el color del estado
    const getStatusColor = (status) => {
        switch (status) {
            case "completed":
                return "bg-green-100 text-green-800"
            case "pending":
                return "bg-yellow-100 text-yellow-800"
            case "cancelled":
                return "bg-red-100 text-red-800"
            default:
                return "bg-neutral-100 text-neutral-800"
        }
    }

    // Función para traducir el estado
    const translateStatus = (status) => {
        switch (status) {
            case "completed":
                return "Completado"
            case "pending":
                return "Pendiente"
            case "cancelled":
                return "Cancelado"
            default:
                return status
        }
    }

    return (
        <div className="container mx-auto py-12 px-4">
            <h1 className="text-2xl font-bold mb-8">Mis Pedidos</h1>

            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="p-6 border-b border-neutral-100">
                    <h2 className="text-lg font-medium">Historial de Pedidos ({orders.length})</h2>
                </div>

                <div className="divide-y divide-neutral-100">
                    {orders.map((order) => (
                        <div key={order.orderId} className="p-6">
                            <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                                <div>
                                    <h3 className="font-medium">Pedido #{order.orderId}</h3>
                                    <div className="flex items-center text-sm text-neutral-500 mt-1">
                                        <Calendar className="h-4 w-4 mr-1" />
                                        <span>{formatDate(order.orderDate)}</span>
                                        <Clock className="h-4 w-4 ml-3 mr-1" />
                                        <span>{formatTime(order.orderDate)}</span>
                                    </div>
                                </div>

                                <div className="flex items-center mt-4 md:mt-0">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                    {translateStatus(order.status)}
                  </span>
                                    <span className="mx-4 font-medium">${order.totalAmount.toFixed(2)}</span>
                                    <Link
                                        href={`/pedidos/${order.orderId}`}
                                        className="text-primary-600 hover:text-primary-700 flex items-center"
                                    >
                                        Ver detalles
                                        <ChevronRight className="h-4 w-4 ml-1" />
                                    </Link>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}
