"use client"

import { useEffect, useState } from "react"
import { useParams, useSearchParams } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { useAuth } from "@/context/AuthContext"
import { getOrderDetails } from "@/services/orderService"
import { CheckCircle, ArrowLeft } from "lucide-react"

export default function OrderDetailPage() {
    const { id } = useParams()
    const searchParams = useSearchParams()
    const showSuccess = searchParams.get("success") === "true"

    const { isAuthenticated } = useAuth()
    const [order, setOrder] = useState(null)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)

    useEffect(() => {
        const fetchOrderDetails = async () => {
            if (!isAuthenticated || !id) return

            setLoading(true)
            setError(null)
            try {
                const data = await getOrderDetails(id)
                setOrder(data)
            } catch (err) {
                console.error(`Error al cargar detalles del pedido ${id}:`, err)
                setError("No se pudieron cargar los detalles del pedido. Por favor, intenta de nuevo más tarde.")
            } finally {
                setLoading(false)
            }
        }

        fetchOrderDetails()
    }, [isAuthenticated, id])

    if (!isAuthenticated) {
        return (
            <div className="container mx-auto py-12 px-4">
                <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden p-8 text-center">
                    <h1 className="text-2xl font-bold mb-4">Acceso Restringido</h1>
                    <p className="text-neutral-600 mb-6">Debes iniciar sesión para ver los detalles del pedido</p>
                    <Link
                        href={`/login?redirect=pedidos/${id}`}
                        className="inline-block bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-6 rounded-lg transition-colors"
                    >
                        Iniciar Sesión
                    </Link>
                </div>
            </div>
        )
    }

    if (loading) {
        return (
            <div className="container mx-auto py-12 px-4">
                <h1 className="text-2xl font-bold mb-8">Detalles del Pedido</h1>
                <div className="flex justify-center">
                    <div className="animate-pulse text-center">
                        <p className="text-neutral-500">Cargando detalles del pedido...</p>
                    </div>
                </div>
            </div>
        )
    }

    if (error) {
        return (
            <div className="container mx-auto py-12 px-4">
                <h1 className="text-2xl font-bold mb-8">Detalles del Pedido</h1>
                <div className="bg-red-50 text-red-700 p-6 rounded-xl">
                    <p>{error}</p>
                </div>
            </div>
        )
    }

    if (!order) {
        return (
            <div className="container mx-auto py-12 px-4">
                <h1 className="text-2xl font-bold mb-8">Detalles del Pedido</h1>
                <div className="bg-white rounded-xl shadow-sm p-8 text-center">
                    <h2 className="text-xl font-medium mb-2">Pedido no encontrado</h2>
                    <p className="text-neutral-500 mb-6">No se encontró el pedido solicitado</p>
                    <Link
                        href="/pedidos"
                        className="inline-block bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-6 rounded-lg transition-colors"
                    >
                        Volver a Mis Pedidos
                    </Link>
                </div>
            </div>
        )
    }

    // Función para traducir el estado
    const translateStatus = (status) => {
        switch (status) {
            case "completed":
                return "Completado"
            case "pending":
                return "Pendiente"
            case "cancelled":
                return "Cancelado"
            default:
                return status
        }
    }

    // Función para obtener el color del estado
    const getStatusColor = (status) => {
        switch (status) {
            case "completed":
                return "bg-green-100 text-green-800"
            case "pending":
                return "bg-yellow-100 text-yellow-800"
            case "cancelled":
                return "bg-red-100 text-red-800"
            default:
                return "bg-neutral-100 text-neutral-800"
        }
    }

    // Calcular el total del pedido
    const orderTotal = order.items.reduce((total, item) => total + item.subtotal, 0)

    return (
        <div className="container mx-auto py-12 px-4">
            <div className="flex items-center mb-8">
                <Link href="/pedidos" className="text-neutral-600 hover:text-neutral-900 flex items-center mr-4">
                    <ArrowLeft className="h-5 w-5 mr-1" />
                    Volver
                </Link>
                <h1 className="text-2xl font-bold">Pedido #{order.orderId}</h1>
            </div>

            {showSuccess && (
                <div className="bg-green-50 text-green-700 p-4 rounded-lg mb-8 flex items-center">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    <span>¡Tu pedido ha sido confirmado con éxito!</span>
                </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                        <div className="p-6 border-b border-neutral-100">
                            <div className="flex justify-between items-center">
                                <h2 className="text-lg font-medium">Productos ({order.items.length})</h2>
                                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                  {translateStatus(order.status)}
                </span>
                            </div>
                        </div>

                        <div className="divide-y divide-neutral-100">
                            {order.items.map((item) => (
                                <div key={item.productId} className="p-6 flex flex-col sm:flex-row items-start sm:items-center">
                                    <div className="relative h-20 w-20 rounded-lg overflow-hidden bg-neutral-100 flex-shrink-0 mb-4 sm:mb-0">
                                        <Image
                                            src={item.imageUrl || "/placeholder.svg"}
                                            alt={item.description || "Producto"}
                                            fill
                                            className="object-cover"
                                        />
                                    </div>

                                    <div className="sm:ml-6 flex-grow">
                                        <h3 className="font-medium">{item.description}</h3>
                                        <p className="text-neutral-500 text-sm">
                                            ${item.priceAtTime.toFixed(2)} x {item.quantity}
                                        </p>
                                    </div>

                                    <div className="mt-4 sm:mt-0 sm:ml-6">
                                        <span className="font-medium">${item.subtotal.toFixed(2)}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="lg:col-span-1">
                    <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
                        <h2 className="text-lg font-medium mb-4">Resumen del Pedido</h2>

                        <div className="space-y-3 mb-6">
                            <div className="flex justify-between">
                                <span className="text-neutral-600">Subtotal</span>
                                <span>${orderTotal.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-neutral-600">Envío</span>
                                <span>Gratis</span>
                            </div>
                            <div className="border-t border-neutral-100 pt-3 flex justify-between font-medium">
                                <span>Total</span>
                                <span>${orderTotal.toFixed(2)}</span>
                            </div>
                        </div>

                        <Link
                            href="/productos"
                            className="w-full bg-primary-600 hover:bg-primary-700 text-white font-medium py-3 px-4 rounded-lg transition-colors text-center block"
                        >
                            Seguir Comprando
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    )
}
