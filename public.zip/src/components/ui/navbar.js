"use client"

import Link from "next/link"
import { Search, Heart, User, ShoppingCart, Menu, X } from "lucide-react"
import { useState } from "react"
import { useAuth } from "@/context/AuthContext"
import { useCart } from "@/context/CartContext"

export default function Navbar() {
    const [isMenuOpen, setIsMenuOpen] = useState(false)
    const { user, isAuthenticated, logout } = useAuth()
    const { itemCount } = useCart()

    return (
        <header className="bg-white border-b border-neutral-100 sticky top-0 z-50">
            <div className="container mx-auto px-4">
                <div className="flex items-center justify-between h-20">
                    {/* Logo */}
                    <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold">
              <span className="text-black">SPORT</span>
              <span className="text-neutral-500">SHOP</span>
            </span>
                    </Link>

                    {/* Desktop Navigation */}
                    <nav className="hidden md:flex items-center space-x-8">
                        <Link href="/running" className="text-neutral-900 hover:text-primary-600 font-medium">
                            RUNNING
                        </Link>
                        <Link href="/futbol" className="text-neutral-900 hover:text-primary-600 font-medium">
                            FÚTBOL
                        </Link>
                        <Link href="/training" className="text-neutral-900 hover:text-primary-600 font-medium">
                            TRAINING
                        </Link>
                        <Link href="/baloncesto" className="text-neutral-900 hover:text-primary-600 font-medium">
                            BALONCESTO
                        </Link>
                        <Link href="/casual" className="text-neutral-900 hover:text-primary-600 font-medium">
                            CASUAL
                        </Link>
                        <Link href="/ofertas" className="text-red-600 hover:text-red-700 font-medium">
                            OFERTAS
                        </Link>
                    </nav>

                    {/* Icons */}
                    <div className="flex items-center space-x-4">
                        <button className="p-2 rounded-full hover:bg-neutral-100" aria-label="Buscar">
                            <Search className="h-5 w-5 text-neutral-700" />
                        </button>
                        <Link href="/wishlist" className="p-2 rounded-full hover:bg-neutral-100" aria-label="Favoritos">
                            <Heart className="h-5 w-5 text-neutral-700" />
                        </Link>

                        {isAuthenticated ? (
                            <div className="relative group">
                                <button className="p-2 rounded-full hover:bg-neutral-100" aria-label="Mi cuenta">
                                    <User className="h-5 w-5 text-neutral-700" />
                                </button>
                                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                                    <div className="px-4 py-2 text-sm text-neutral-700 border-b border-neutral-100">
                                        Hola, {user?.firstName || "Usuario"}
                                    </div>
                                    <Link href="/perfil" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100">
                                        Mi Perfil
                                    </Link>
                                    <Link href="/pedidos" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100">
                                        Mis Pedidos
                                    </Link>
                                    <button
                                        onClick={logout}
                                        className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                                    >
                                        Cerrar Sesión
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <Link href="/login" className="p-2 rounded-full hover:bg-neutral-100" aria-label="Iniciar sesión">
                                <User className="h-5 w-5 text-neutral-700" />
                            </Link>
                        )}

                        <Link href="/cart" className="p-2 rounded-full hover:bg-neutral-100 relative" aria-label="Carrito">
                            <ShoppingCart className="h-5 w-5 text-neutral-700" />
                            {itemCount > 0 && (
                                <span className="absolute -top-1 -right-1 bg-black text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {itemCount}
                </span>
                            )}
                        </Link>

                        {/* Mobile Menu Button */}
                        <button
                            className="md:hidden p-2 rounded-md hover:bg-neutral-100"
                            onClick={() => setIsMenuOpen(!isMenuOpen)}
                            aria-label={isMenuOpen ? "Cerrar menú" : "Abrir menú"}
                        >
                            {isMenuOpen ? <X className="h-6 w-6 text-neutral-700" /> : <Menu className="h-6 w-6 text-neutral-700" />}
                        </button>
                    </div>
                </div>

                {/* Mobile Menu */}
                {isMenuOpen && (
                    <div className="md:hidden py-4 border-t border-neutral-100">
                        <nav className="flex flex-col space-y-4">
                            <Link
                                href="/running"
                                className="text-neutral-900 hover:text-primary-600 font-medium"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                RUNNING
                            </Link>
                            <Link
                                href="/futbol"
                                className="text-neutral-900 hover:text-primary-600 font-medium"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                FÚTBOL
                            </Link>
                            <Link
                                href="/training"
                                className="text-neutral-900 hover:text-primary-600 font-medium"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                TRAINING
                            </Link>
                            <Link
                                href="/baloncesto"
                                className="text-neutral-900 hover:text-primary-600 font-medium"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                BALONCESTO
                            </Link>
                            <Link
                                href="/casual"
                                className="text-neutral-900 hover:text-primary-600 font-medium"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                CASUAL
                            </Link>
                            <Link
                                href="/ofertas"
                                className="text-red-600 hover:text-red-700 font-medium"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                OFERTAS
                            </Link>

                            {isAuthenticated ? (
                                <>
                                    <div className="border-t border-neutral-100 pt-4 mt-4"></div>
                                    <Link
                                        href="/perfil"
                                        className="text-neutral-900 hover:text-primary-600"
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Mi Perfil
                                    </Link>
                                    <Link
                                        href="/pedidos"
                                        className="text-neutral-900 hover:text-primary-600"
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Mis Pedidos
                                    </Link>
                                    <button
                                        onClick={() => {
                                            logout()
                                            setIsMenuOpen(false)
                                        }}
                                        className="text-left text-neutral-900 hover:text-primary-600"
                                    >
                                        Cerrar Sesión
                                    </button>
                                </>
                            ) : (
                                <>
                                    <div className="border-t border-neutral-100 pt-4 mt-4"></div>
                                    <Link
                                        href="/login"
                                        className="text-neutral-900 hover:text-primary-600"
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Iniciar Sesión
                                    </Link>
                                    <Link
                                        href="/register"
                                        className="text-neutral-900 hover:text-primary-600"
                                        onClick={() => setIsMenuOpen(false)}
                                    >
                                        Registrarse
                                    </Link>
                                </>
                            )}
                        </nav>
                    </div>
                )}
            </div>
        </header>
    )
}
