export default function AnnouncementBar() {
    return (
        <div className="bg-black text-white text-center py-2 px-4 text-sm">
            Envío gratis en compras mayores a $50 | Recogida en tienda disponible
        </div>
    )
}
