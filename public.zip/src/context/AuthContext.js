"use client"

import { createContext, useState, useEffect, useContext } from "react"
import { isAuthenticated, loginUser, logoutUser, registerUser } from "@/services/authService"
import { getUserProfile } from "@/services/userService"

// Crear el contexto
const AuthContext = createContext()

// Proveedor del contexto
export function AuthProvider({ children }) {
    const [user, setUser] = useState(null)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)

    // Cargar usuario al iniciar
    useEffect(() => {
        const loadUser = async () => {
            try {
                if (isAuthenticated()) {
                    const userData = await getUserProfile()
                    setUser(userData)
                }
            } catch (err) {
                console.error("Error al cargar usuario:", err)
                // Si hay un error al cargar el usuario, probablemente el token es inválido
                logoutUser()
            } finally {
                setLoading(false)
            }
        }

        loadUser()
    }, [])

    // Función para iniciar sesión
    const login = async (credentials) => {
        setLoading(true)
        setError(null)
        try {
            const response = await loginUser(credentials)
            const userData = await getUserProfile()
            setUser(userData)
            return userData
        } catch (err) {
            setError(err.message || "Error al iniciar sesión")
            throw err
        } finally {
            setLoading(false)
        }
    }

    // Función para registrarse
    const register = async (userData) => {
        setLoading(true)
        setError(null)
        try {
            const response = await registerUser(userData)
            // Después de registrarse, iniciamos sesión automáticamente
            await login({
                email: userData.email,
                password: userData.password,
            })
            return response
        } catch (err) {
            setError(err.message || "Error al registrarse")
            throw err
        } finally {
            setLoading(false)
        }
    }

    // Función para cerrar sesión
    const logout = () => {
        logoutUser()
        setUser(null)
    }

    // Valor del contexto
    const value = {
        user,
        loading,
        error,
        isAuthenticated: !!user,
        login,
        register,
        logout,
    }

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

// Hook personalizado para usar el contexto
export function useAuth() {
    return useContext(AuthContext)
}
