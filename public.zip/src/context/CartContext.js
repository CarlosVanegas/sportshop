"use client"

import { createContext, useState, useEffect, useContext } from "react"
import { getCartItems, addCartItem, removeCartItem, updateCartItemQuantity } from "@/services/cartService"
import { useAuth } from "./AuthContext"

// Crear el contexto
const CartContext = createContext()

// Proveedor del contexto
export function CartProvider({ children }) {
    const [cartItems, setCartItems] = useState([])
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)
    const { isAuthenticated } = useAuth()

    // Cargar carrito al iniciar o cuando cambia la autenticación
    useEffect(() => {
        if (isAuthenticated) {
            loadCart()
        } else {
            setCartItems([])
        }
    }, [isAuthenticated])

    // Función para cargar el carrito
    const loadCart = async () => {
        if (!isAuthenticated) return

        setLoading(true)
        setError(null)
        try {
            console.log("Cargando carrito...")
            const items = await getCartItems()
            console.log("Items del carrito obtenidos:", items)
            setCartItems(items || [])
        } catch (err) {
            console.error("Error al cargar el carrito:", err)
            setError(err.message || "Error al cargar el carrito")
            // En caso de error, mantener el carrito actual o establecerlo como vacío
            setCartItems([])
        } finally {
            setLoading(false)
        }
    }

    // Función para agregar un item al carrito
    const addToCart = async (productId, quantity = 1) => {
        if (!isAuthenticated) {
            setError("Debes iniciar sesión para añadir productos al carrito")
            return null
        }

        setLoading(true)
        setError(null)
        try {
            console.log(`Añadiendo producto ${productId} al carrito, cantidad: ${quantity}`)
            const newItem = await addCartItem({ productId, quantity })
            console.log("Item añadido:", newItem)

            setCartItems((prevItems) => {
                // Si el item ya existe, actualizamos la cantidad
                const existingItemIndex = prevItems.findIndex((item) => item.productId === productId)
                if (existingItemIndex >= 0) {
                    const updatedItems = [...prevItems]
                    updatedItems[existingItemIndex] = newItem
                    return updatedItems
                }
                // Si no existe, lo agregamos
                return [...prevItems, newItem]
            })
            return newItem
        } catch (err) {
            console.error("Error al agregar al carrito:", err)
            setError(err.message || "Error al agregar al carrito")
            return null
        } finally {
            setLoading(false)
        }
    }

    // Función para eliminar un item del carrito
    const removeFromCart = async (itemId) => {
        if (!isAuthenticated) return

        setLoading(true)
        setError(null)
        try {
            await removeCartItem(itemId)
            setCartItems((prevItems) => prevItems.filter((item) => item.id !== itemId))
        } catch (err) {
            setError(err.message || "Error al eliminar del carrito")
            throw err
        } finally {
            setLoading(false)
        }
    }

    // Función para actualizar la cantidad de un item
    const updateQuantity = async (itemId, quantity) => {
        if (!isAuthenticated) return

        setLoading(true)
        setError(null)
        try {
            const updatedItem = await updateCartItemQuantity(itemId, quantity)
            setCartItems((prevItems) => prevItems.map((item) => (item.id === itemId ? updatedItem : item)))
            return updatedItem
        } catch (err) {
            setError(err.message || "Error al actualizar cantidad")
            throw err
        } finally {
            setLoading(false)
        }
    }

    // Calcular el total del carrito
    const cartTotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0)

    // Calcular el número total de items
    const itemCount = cartItems.reduce((count, item) => count + item.quantity, 0)

    // Valor del contexto
    const value = {
        cartItems,
        loading,
        error,
        cartTotal,
        itemCount,
        addToCart,
        removeFromCart,
        updateQuantity,
        refreshCart: loadCart,
    }

    return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

// Hook personalizado para usar el contexto
export function useCart() {
    return useContext(CartContext)
}
