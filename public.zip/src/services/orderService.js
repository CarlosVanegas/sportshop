import { api } from "./api"

/**
 * Confirma el pedido actual (convierte el carrito en orden)
 * @returns {Promise<Object>} - Datos de la orden creada
 */
export const confirmOrder = async () => {
    try {
        return await api.post("/orders")
    } catch (error) {
        console.error("Error al confirmar pedido:", error)
        throw error
    }
}

/**
 * Obtiene todas las órdenes del usuario
 * @returns {Promise<Array>} - Lista de órdenes
 */
export const getUserOrders = async () => {
    try {
        return await api.get("/orders")
    } catch (error) {
        console.error("Error al obtener órdenes del usuario:", error)
        throw error
    }
}

/**
 * Obtiene el detalle de una orden específica
 * @param {number} orderId - ID de la orden
 * @returns {Promise<Object>} - Detalle de la orden
 */
export const getOrderDetails = async (orderId) => {
    try {
        return await api.get(`/orders/${orderId}`)
    } catch (error) {
        console.error(`Error al obtener detalle de la orden ${orderId}:`, error)
        throw error
    }
}
