// Configuración base para las llamadas a la API
// Usamos un proxy interno para evitar problemas de CORS
const API_BASE_URL = "/api/proxy"

// Mejorar la función handleApiError para proporcionar más información sobre el error
const handleApiError = async (response) => {
    if (!response.ok) {
        // Para errores de red como CORS o servidor no disponible
        if (response.status === 0 || response.status === 404 || response.status === 500) {
            console.error(`Error de conexión: No se pudo conectar a ${API_BASE_URL}`)
            throw new Error(`No se pudo conectar al servidor. Verifica que el servidor esté en ejecución.`)
        }

        try {
            const errorData = await response.json()
            const errorMessage = errorData?.message || errorData?.error || `Error ${response.status}: ${response.statusText}`
            throw new Error(errorMessage)
        } catch (e) {
            // Si no se puede parsear la respuesta como JSON
            throw new Error(`Error ${response.status}: ${response.statusText}`)
        }
    }

    // Para respuestas vacías (como 204 No Content)
    if (response.status === 204) {
        return true
    }

    // Intentar parsear la respuesta como JSON
    try {
        return await response.json()
    } catch (e) {
        console.warn("La respuesta no es JSON válido:", e)
        return {}
    }
}

// Función para obtener el token de autenticación
const getAuthToken = () => {
    if (typeof window !== "undefined") {
        return localStorage.getItem("auth_token")
    }
    return null
}

// Modificar la función apiRequest para incluir más opciones y mejor manejo de errores
export const apiRequest = async (endpoint, options = {}) => {
    const token = getAuthToken()

    const defaultHeaders = {
        "Content-Type": "application/json",
    }

    if (token) {
        defaultHeaders["Authorization"] = `Bearer ${token}`
    }

    const config = {
        ...options,
        headers: {
            ...defaultHeaders,
            ...options.headers,
        },
    }

    try {
        console.log(`Realizando solicitud a: ${API_BASE_URL}${endpoint}`)
        const response = await fetch(`${API_BASE_URL}${endpoint}`, config)
        console.log("Respuesta recibida:", response.status)
        return handleApiError(response)
    } catch (error) {
        console.error("Error de red:", error)
        throw new Error(`Error de conexión: ${error.message}. Verifica que el servidor esté en ejecución.`)
    }
}

// Exportamos métodos HTTP comunes
export const api = {
    get: (endpoint, options = {}) => apiRequest(endpoint, { ...options, method: "GET" }),
    post: (endpoint, data, options = {}) =>
        apiRequest(endpoint, {
            ...options,
            method: "POST",
            body: JSON.stringify(data),
        }),
    put: (endpoint, data, options = {}) =>
        apiRequest(endpoint, {
            ...options,
            method: "PUT",
            body: JSON.stringify(data),
        }),
    delete: (endpoint, options = {}) => apiRequest(endpoint, { ...options, method: "DELETE" }),
}
